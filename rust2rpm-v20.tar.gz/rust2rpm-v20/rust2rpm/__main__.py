import argparse
import ast
import configparser
import contextlib
from datetime import datetime, timezone
import difflib
import functools
import itertools
import os
import pathlib
import re
import shlex
import shutil
import sys
import tarfile
import tempfile
import time
import subprocess

import jinja2
import requests
import tqdm

from . import Metadata, licensing, __version__
from .metadata import normalize_deps

DEFAULT_EDITOR = "vi"
XDG_CACHE_HOME = os.getenv("XDG_CACHE_HOME", os.path.expanduser("~/.cache"))
CACHEDIR = os.path.join(XDG_CACHE_HOME, "rust2rpm")
API_URL = "https://crates.io/api/v1/"
DIST_GIT_URL = "https://src.fedoraproject.org/api/0/"
JINJA_ENV = jinja2.Environment(
    loader=jinja2.ChoiceLoader([
        jinja2.FileSystemLoader(["/"]),
        jinja2.PackageLoader("rust2rpm", "templates"),
    ]),
    extensions=["jinja2.ext.do"],
    trim_blocks=True,
    lstrip_blocks=True)
LICENSES = re.compile(
         r"(COPYING|COPYING[\.\-].*|COPYRIGHT|COPYRIGHT[\.\-].*|"
         r"EULA|EULA[\.\-].*|[Ll]icen[cs]e|[Ll]icen[cs]e.*|LICEN[CS]E|"
         r"LICEN[CS]E[\.\-].*|.*[\.\-]LICEN[CS]E.*|NOTICE|NOTICE[\.\-].*|"
         r"PATENTS|PATENTS[\.\-].*|UNLICEN[CS]E|UNLICEN[CS]E[\.\-].*|"
         r"agpl[\.\-].*|gpl[\.\-].*|lgpl[\.\-].*|AGPL-.*[0-9].*|"
         r"APACHE-.*[0-9].*|BSD-.*[0-9].*|CC-BY-.*|GFDL-.*[0-9].*|"
         r"GNU-.*[0-9].*|GPL-.*[0-9].*|LGPL-.*[0-9].*|MIT-.*[0-9].*|"
         r"MPL-.*[0-9].*|OFL-.*[0-9].*)")

def sortify(func):
    """Return a sorted list from a generator"""
    def wrapper(*args, **kwargs):
        return sorted(func(*args, **kwargs))
    return functools.update_wrapper(wrapper, func)

def read_os_release():
    try:
        f = open('/etc/os-release')
    except FileNotFoundError:
        f = open('/usr/lib/os-release')

    for line in f:
        line = line.rstrip()
        if not line or line.startswith('#'):
            continue
        m = re.match(r'([A-Z][A-Z_0-9]+)=(.*)', line)
        if m:
            name, val = m.groups()
            if val and val[0] in '"\'':
                val = ast.literal_eval(val)
            yield name, val

def get_default_target():
    os_release = dict(read_os_release())
    os_id = os_release.get("ID")
    # ID_LIKE is a space-separated list of identifiers like ID
    os_like = os_release.get("ID_LIKE", "").split()

    # Order matters here!
    if "mageia" in (os_id, *os_like):
        return "mageia"
    elif "fedora" in (os_id, *os_like):
        return "fedora"
    elif "suse" in os_like:
        return "opensuse"
    else:
        return "plain"

def detect_editor():
    terminal = os.getenv("TERM")
    terminal_is_dumb = terminal is None or terminal == "dumb"
    editor = None
    if not terminal_is_dumb:
        editor = os.getenv("VISUAL")
    if editor is None:
        editor = os.getenv("EDITOR")
    if editor is None:
        if terminal_is_dumb:
            raise Exception("Terminal is dumb, but EDITOR unset")
        else:
            editor = DEFAULT_EDITOR
    return editor

def detect_packager():
    # If we're forcing the fallback...
    if os.getenv("RUST2RPM_NO_DETECT_PACKAGER") is not None:
        return None

    # If we're supplying packager identity through an environment variable...
    packager_identity = os.getenv("RUST2RPM_PACKAGER")
    if packager_identity is not None:
        return packager_identity

    # If we're detecting packager identity through rpmdev-packager...
    rpmdev_packager = shutil.which("rpmdev-packager")
    if rpmdev_packager is not None:
        return subprocess.check_output(rpmdev_packager, universal_newlines=True).strip()

    # If we're detecting packager identity through git configuration...
    git = shutil.which("git")
    if git is not None:
        name = subprocess.check_output([git, "config", "user.name"], universal_newlines=True).strip()
        email = subprocess.check_output([git, "config", "user.email"], universal_newlines=True).strip()
        return f"{name} <{email}>"

    return None

def file_mtime(path):
    return datetime.fromtimestamp(os.stat(path).st_mtime, timezone.utc).isoformat()

@contextlib.contextmanager
def remove_on_error(path):
    try:
        yield
    except: # this is supposed to include ^C
        os.unlink(path)
        raise

def local_toml(toml, version):
    if os.path.isdir(toml):
        doc_files = get_doc_files(toml)
        license_files = get_license_files(toml)
        toml = os.path.join(toml, "Cargo.toml")
    else:
        doc_files = []
        license_files = []

    return toml, None, version, doc_files, license_files

def local_crate(crate, version):
    cratename, version = os.path.basename(crate)[:-6].rsplit("-", 1)
    return crate, cratename, version

def download(crate, version):
    if version is None:
        # Now we need to get latest version
        url = requests.compat.urljoin(API_URL, f"crates/{crate}/versions")
        req = requests.get(url, headers={"User-Agent": "rust2rpm"})
        req.raise_for_status()
        versions = req.json()["versions"]
        version = next(version["num"] for version in versions if not version["yanked"])

    os.makedirs(CACHEDIR, exist_ok=True)
    cratef_base = f"{crate}-{version}.crate"
    cratef = os.path.join(CACHEDIR, cratef_base)
    if not os.path.isfile(cratef):
        url = requests.compat.urljoin(API_URL, f"crates/{crate}/{version}/download#")
        req = requests.get(url, stream=True, headers={"User-Agent": "rust2rpm"})
        req.raise_for_status()
        total = int(req.headers["Content-Length"])
        with remove_on_error(cratef), open(cratef, "wb") as f:
            for chunk in tqdm.tqdm(req.iter_content(), f"Downloading {cratef_base}".format(cratef_base),
                                   total=total, unit="B", unit_scale=True):
                f.write(chunk)
    return cratef, crate, version

@contextlib.contextmanager
def files_from_crate(cratef, crate, version):
    with tempfile.TemporaryDirectory() as tmpdir:
        target_dir = f"{tmpdir}/"
        with tarfile.open(cratef, "r") as archive:
            for n in archive.getnames():
                if not os.path.abspath(os.path.join(target_dir, n)).startswith(target_dir):
                    raise Exception("Unsafe filenames!")
            archive.extractall(target_dir)
        toml_relpath = f"{crate}-{version}/Cargo.toml"
        toml = f"{tmpdir}/{toml_relpath}"
        if not os.path.isfile(toml):
            raise IOError("crate does not contain Cargo.toml file")
        root_path = f"{tmpdir}/{crate}-{version}"
        doc_files = get_doc_files(root_path)
        license_files = get_license_files(root_path)
        yield toml, doc_files, license_files

def make_patch(toml, enabled=True, tmpfile=False):
    if not enabled:
        return []

    editor = detect_editor()

    mtime_before = file_mtime(toml)
    toml_before = open(toml).readlines()

    # When we are editing a git checkout, we should not modify the real file.
    # When we are editing an unpacked crate, we are free to edit anything.
    # Let's keep the file name as close as possible to make editing easier.
    if tmpfile:
        tmpfile = tempfile.NamedTemporaryFile("w+t", dir=os.path.dirname(toml),
                                              prefix="Cargo.", suffix=".toml")
        tmpfile.writelines(toml_before)
        tmpfile.flush()
        fname = tmpfile.name
    else:
        fname = toml
    subprocess.check_call([editor, fname])
    mtime_after = file_mtime(toml)
    toml_after = open(fname).readlines()
    toml_relpath = "/".join(toml.split("/")[-2:])
    diff = list(difflib.unified_diff(toml_before, toml_after,
                                     fromfile=toml_relpath, tofile=toml_relpath,
                                     fromfiledate=mtime_before, tofiledate=mtime_after))
    return diff

def _is_path(path):
    return "/" in path or path in {".", ".."}

@sortify
def get_license_files(path):
    exclude = { "vendor", "example", "examples", "_example", "_examples",
                "testdata", "_testdata", ".github", "tests", "test" }
    for root, dirs, files in os.walk(path, topdown=True):
        dirs[:] = [d for d in dirs if d not in exclude]
        for f in files:
            if LICENSES.match(f):
                yield os.path.relpath(os.path.join(root, f), path)

@sortify
def get_doc_files(path):
    matcher = re.compile(
        r"(.*\.md|.*\.markdown|.*\.mdown|.*\.mkdn|.*\.rst|.*\.txt|AUTHORS|"
        r"AUTHORS[\.\-].*|CONTRIBUTORS|CONTRIBUTORS[\.\-].*|README|"
        r"README[\.\-].*|CHANGELOG|CHANGELOG[\.\-].*|TODO|TODO[\.\-].*)",
        re.IGNORECASE)
    matcherex = re.compile(r"CMakeLists\.txt")
    for root, dirs, files in os.walk(path, topdown=True):
        dirs[:] = []
        for f in files:
            if matcher.match(f) and not LICENSES.match(f) and not matcherex.match(f):
                yield os.path.relpath(os.path.join(root, f), path)

def get_package_info(package):
    url = requests.compat.urljoin(DIST_GIT_URL, f"rpms/{package}")
    req = requests.get(url, headers={"User-Agent": "rust2rpm"})
    json = req.json()
    if "name" in json:
        return json
    else:
        return None

def make_diff_metadata(crate, version, patch=False, store=False):
    if _is_path(crate):
        # Only things that look like a paths are considered local arguments
        if crate.endswith(".crate"):
            cratef, crate, version = local_crate(crate, version)
        else:
            if store:
                raise ValueError("--store-crate can only be used for a crate")

            toml, crate, version, doc_files, license_files = local_toml(crate, version)
            diff = make_patch(toml, enabled=patch, tmpfile=True)
            metadata = Metadata.from_file(toml)
            if len(metadata) > 1:
                print(f"Warning: multiple metadata for {toml}")
            metadata = metadata[0]
            return metadata.name, diff, metadata, doc_files, license_files
    else:
        cratef, crate, version = download(crate, version)

    with files_from_crate(cratef, crate, version) as (toml, doc_files, license_files):
        diff = make_patch(toml, enabled=patch)
        metadata = Metadata.from_file(toml)
        if len(metadata) > 1:
            print(f"Warning: multiple metadata for {toml}")
        metadata = metadata[0]
    if store:
        shutil.copy2(cratef, os.path.join(os.getcwd(), f"{metadata.name}-{version}.crate"))
    return crate, diff, metadata, doc_files, license_files

def to_list(s):
    if not s:
        return []
    return list(filter(None, (l.strip() for l in s.splitlines())))

def detect_rpmautospec(default_target, spec_file):
    # We default to on only for selected distros for now…
    if default_target not in {"fedora"}:
        return False

    try:
        text = spec_file.read_text()
    except FileNotFoundError:
        # A new file, let's try the new thing.
        return True

    # We are redoing an existing spec file. Figure out if it had
    # %autochangelog enabled before.
    autochangelog_re = r"^\s*%(?:autochangelog|\{\??autochangelog\})\b"
    return any(re.match(autochangelog_re, line) for line in text.splitlines())


@contextlib.contextmanager
def exit_on_common_errors():
    """Suppress tracebacks on common "expected" exceptions"""
    try:
        yield
    except requests.exceptions.HTTPError as e:
        sys.exit(f'Failed to download metadata: {e}')
    except subprocess.CalledProcessError as e:
        cmd = shlex.join(e.cmd)
        sys.exit(f'Subcommand failed with code {e.returncode}: {cmd}')
    except FileNotFoundError as e:
        sys.exit(str(e))


@exit_on_common_errors()
def main():
    default_target = get_default_target()

    parser = argparse.ArgumentParser("rust2rpm",
                                     formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument("--show-license-map", action="store_true",
                        help="Print license mappings and exit")
    parser.add_argument("--translate-license", action="store_true",
                        help="Print mapping for specified license and exit")
    parser.add_argument("--no-auto-changelog-entry", action="store_true",
                        help="Do not generate a changelog entry")
    parser.add_argument("--no-existence-check", action="store_true",
                        help="Do not check whether the package already exists in dist-git")
    parser.add_argument("-", "--stdout", action="store_true",
                        help="Print spec and patches into stdout")
    parser.add_argument("-t", "--target", action="store",
                        choices=("plain", "fedora", "mageia", "opensuse"), default=default_target,
                        help="Distribution target")
    parser.add_argument("-p", "--patch", action="store_true",
                        help="Do initial patching of Cargo.toml")
    parser.add_argument("-s", "--store-crate", action="store_true",
                        help="Store crate in current directory")
    parser.add_argument("-a", "--rpmautospec", action="store_true",
                        help="Use autorelease and autochangelog features")
    parser.add_argument("--all-features", action="store_true",
                        help="Activate all available features")
    parser.add_argument("--dynamic-buildrequires", action="store_true",
                        help="Use dynamic BuildRequires feature")
    parser.add_argument("--no-dynamic-buildrequires", action="store_true",
                        help="Do not use dynamic BuildRequires feature")
    parser.add_argument("--suffix", action="store",
                        help="Package suffix")
    parser.add_argument("crate", help="crates.io name\n"
                                      "path/to/local.crate\n"
                                      "path/to/project/",
                        nargs="?")
    parser.add_argument("version", nargs="?", help="crates.io version")
    args = parser.parse_args()

    if args.show_license_map:
        licensing.dump_sdpx_to_fedora_map(sys.stdout)
        return

    if args.translate_license:
        license, comments = licensing.translate_license(args.target, args.crate)
        if comments:
            print(comments)
        print(license)
        return

    if args.crate is None:
        parser.error("required crate/path argument missing")

    crate, diff, metadata, doc_files, license_files = make_diff_metadata(
        args.crate, args.version, patch=args.patch, store=args.store_crate)

    JINJA_ENV.globals["normalize_deps"] = normalize_deps
    JINJA_ENV.globals["to_list"] = to_list
    template = JINJA_ENV.get_template("main.spec")

    if args.patch and len(diff) > 0:
        patch_file = f"{metadata.name}-fix-metadata.diff"
    else:
        patch_file = None

    kwargs = {}
    kwargs["generator_version"] = __version__
    kwargs["crate"] = crate
    kwargs["target"] = args.target
    kwargs["all_features"] = args.all_features
    bins = [tgt for tgt in metadata.targets if tgt.kind == "bin"]
    libs = [tgt for tgt in metadata.targets if tgt.kind in {"lib", "rlib", "proc-macro"}]
    is_bin = len(bins) > 0
    is_lib = len(libs) > 0
    if is_bin:
        kwargs["include_main"] = True
        kwargs["bins"] = bins
    elif is_lib:
        kwargs["include_main"] = False
    else:
        raise ValueError("No bins and no libs")
    kwargs["include_devel"] = is_lib

    if args.suffix is not None:
        if metadata.name[-1].isdigit():
            suffix = f'-{args.suffix}'
        else:
            suffix = args.suffix
    else:
        suffix = ""
    kwargs["pkg_suffix"] = suffix
    spec_file = pathlib.Path(f"rust-{metadata.name}{suffix}.spec")

    if args.target in {"fedora"} and not args.no_existence_check and not os.path.exists(spec_file):
        # No specfile, so this is probably a new package
        package_info = get_package_info(f"rust-{metadata.name}{suffix}")
        if package_info:
            print(f"Crate {metadata.name}{suffix} is already packaged in Fedora ({package_info['full_url']}).")
            print("Re-run with --no-existence-check if you still want to convert it.")
            sys.exit(1)

    kwargs["auto_changelog_entry"] = not args.no_auto_changelog_entry

    rpmautospec = args.rpmautospec or detect_rpmautospec(default_target, spec_file)
    kwargs["rpmautospec"] = rpmautospec

    if args.target in {"fedora", "mageia", "opensuse"}:
        kwargs["include_build_requires"] = True
        kwargs["include_provides"] = False
        kwargs["include_requires"] = False
    elif args.target == "plain":
        kwargs["include_build_requires"] = True
        kwargs["include_provides"] = True
        kwargs["include_requires"] = True
    else:
        assert False, f"Unknown target {args.target!r}"

    if args.target == "mageia":
        kwargs["pkg_release"] = "%mkrel 1"
        kwargs["rust_group"] = "Development/Rust"
    elif args.target == "opensuse":
        kwargs["spec_copyright_year"] = time.strftime("%Y")
        kwargs["pkg_release"] = "0"
        kwargs["rust_group"] = "Development/Libraries/Rust"
    elif rpmautospec:
        kwargs["pkg_release"] = "%autorelease"
    else:
        kwargs["pkg_release"] = "1%{?dist}"

    if args.target == "fedora" and not args.no_dynamic_buildrequires:
        args.dynamic_buildrequires = True

    kwargs["generate_buildrequires"] = args.dynamic_buildrequires

    if args.target in {"opensuse"}:
        kwargs["date"] = time.strftime("%a %b %d %T %Z %Y")
    else:
        kwargs["date"] = time.strftime("%a %b %d %Y")
    packager_identity = detect_packager()
    if packager_identity is not None:
        kwargs["packager"] = packager_identity

    if metadata.license is not None:
        license, comments = licensing.translate_license(args.target, metadata.license)
        kwargs["license"] = license
        kwargs["license_comments"] = comments

    kwargs["doc_files"] = doc_files
    kwargs["license_files"] = license_files

    conf = configparser.ConfigParser(interpolation=configparser.ExtendedInterpolation())
    conf.read(["_rust2rpm.conf", ".rust2rpm.conf"])
    if args.target not in conf:
        conf.add_section(args.target)

    kwargs["distconf"] = conf[args.target]

    spec_contents = template.render(md=metadata, patch_file=patch_file, **kwargs)
    if args.stdout:
        print(f"# {spec_file}")
        print(spec_contents)
        if patch_file is not None:
            print(f"# {patch_file}")
            print("".join(diff), end="")
    else:
        with open(spec_file, "w") as fobj:
            fobj.write(spec_contents)
            fobj.write("\n")
        if patch_file is not None:
            with open(patch_file, "w") as fobj:
                fobj.writelines(diff)


if __name__ == "__main__":
    main()
